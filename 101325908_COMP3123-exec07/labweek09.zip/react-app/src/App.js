import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <h1>Welcome to Fullstack Development - 1</h1>
        <h3>React JS Programming Week09 Lab exercise</h3>
        <h4>101325908</h4>
        <h5>Hoon Yim</h5>
        <h6>George Brown College, Toronto</h6>
      </header>
    </div>
  );
}

export default App;
